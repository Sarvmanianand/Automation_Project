package main_programs;
import java.io.File;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollingofPage {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\Browser Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		Thread.sleep(2000);
		driver.findElement(By.linkText("Agile Project")).click();
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		js.executeScript("window.scrollTo(0,-document.body.scrollHeight)");
		
		obj.closeBrowser(driver);
		
		
	     
		
		
		
		
		

	}

}
