package main_programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TitleVerification_NavigationCommands {
	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\Browser Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		driver.manage().deleteAllCookies();
		//task 1: Title Verification
		// System.out.println(driver.getCurrentUrl());
		//System.out.println(driver.getTitle());  
		String acceptedTitle="Insurance Broker System - Login";
		String actualTitle=driver.getTitle();
		if(actualTitle.equals(acceptedTitle)) 
		{
			System.out.println("Title Verification Passed");
		}
		else
		{
			System.out.println("Title Verification failed");
		}
		// task 2: Navigation Comands
		driver.findElement(By.className("header")).click();
        Thread.sleep(2000);
        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().forward();
        Thread.sleep(2000);
        driver.navigate().refresh();
        Thread.sleep(2000);
        driver.navigate().to("https://demo.guru99.com/insurance/v1/index.php");
        
		
		
        

	}

}
