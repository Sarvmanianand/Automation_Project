package main_programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", ".\\Browser Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);

		obj.maximizeBrowser(driver);
		Thread.sleep(2000);
		

		Thread.sleep(2000);
		
		driver.findElement(By.linkText("Register")).click();	
		Thread.sleep(3000);
		
		Select s =new Select(driver.findElement(By.xpath("//select[@name='title']")));
		s.selectByIndex(1);
	
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Sarvmani");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Anand");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='phone']")).sendKeys("842383065234");
		Thread.sleep(3000);


		
		Select s1 =new Select(driver.findElement(By.xpath("//select[@name='year']")));

		s1.selectByIndex(60);

		

		Select s2 =new Select(driver.findElement(By.xpath("//select[@name='month']")));

		s2.selectByIndex(7);
		Select s3 =new Select(driver.findElement(By.xpath("//select[@name='date']")));

		s3.selectByIndex(22);

		driver.findElement(By.name("month")).click();
		Thread.sleep(1000);
		
		Select s4 =new Select(driver.findElement(By.xpath("//select[@name='licenceperiod']")));

		s4.selectByIndex(3); 
		
		Select s5 =new Select(driver.findElement(By.xpath("//select[@name='occupation']")));

		s5.selectByIndex(5); 
		
		driver.findElement(By.xpath("//input[@name='street']")).sendKeys("Adarsh Nagar");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='city']")).sendKeys("Siwan");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='county']")).sendKeys("India");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='post_code']")).sendKeys("845412");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("anand456@gmail.com");
		Thread.sleep(3000);

		
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("anand123");
		Thread.sleep(3000);
		

		driver.findElement(By.xpath("//input[@name='c_password']")).sendKeys("anand123");
		Thread.sleep(3000);

		

		driver.findElement(By.xpath("//input[@name='submit']")).click();
		Thread.sleep(3000);
		
		
		
		obj.closeBrowser(driver);


	}

}
