package main_programs;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CrossBrowser_Testing {

	public static void main(String[] args) throws Exception {
		Scanner s= new Scanner(System.in);
		System.out.println("Enter:1 for Chrome/n Enter:3 for Firefox");
		int input=s.nextInt();
		WebDriver driver=null;
		
		
		switch(input)
		 {
		 case 1:
			 System.setProperty("webdriver.chrome.driver", ".\\Browser Extension\\chromedriver.exe");
			 driver =new ChromeDriver();
			 
	     break;
		 case 2:
		 System.setProperty("webdriver.gecko.driver", "D:\\Automation Testing\\Browser Extension\\geckodriver.exe");
		 driver =new ChromeDriver();
		 break;
		 
		 default:
			 System.out.println("Invalid Selection");
		 }
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		Thread.sleep(2000);
		obj.closeBrowser(driver);
		

	}

}
