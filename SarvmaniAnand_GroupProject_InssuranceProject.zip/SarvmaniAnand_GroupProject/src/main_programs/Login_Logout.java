package main_programs;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Logout {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver",".\\Browser Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		obj.maximizeBrowser(driver);
		obj.enterEmail(driver, "anand456@gmail.com");
        obj.enterPassword(driver, "anand123");
        obj.clickOnLoginButton(driver);
        obj.clickOnLogOutButton(driver);
        
        obj.closeBrowser(driver);
	}

}
