package main_programs;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mouse_Hover {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\Browser Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		obj.maximizeBrowser(driver);
		//Mouse Hover
		Actions a = new Actions(driver);
		List<WebElement> ls=driver.findElements(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li"));
		
		//step 3: list size >>  End range which will use in  for loop
		int size= ls.size();
		System.out.println("No. of Elements :"+size);
		// step 4: for loop
		for(int i=1;i<=size;i++) {
			//wait
			Thread.sleep(2000);
			System.out.println(driver.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li["+i+"]")).getText());
			a.moveToElement(driver.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li["+i+"]"))).click().perform();
		}
		obj.closeBrowser(driver);
		

	}

}
