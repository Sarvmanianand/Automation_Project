package mainFunctionalities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class FunctionalitiesChecking {
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() throws Exception 
	
	{
		 System.setProperty("webdriver.chrome.driver",".\\Browser_Extension\\chromedriver.exe");
			 driver =new ChromeDriver();
			driver.manage().window().maximize();
			Thread.sleep(2000);
			driver.manage().deleteAllCookies();
			Thread.sleep(2000);
			driver.get("https://letcode.in/");
			Thread.sleep(2000);
			
				
	  }
	
  @Test(priority = 1 , description = "Checking with workSpace")
  public void workspace() throws Exception 
  {

	  driver.findElement(By.linkText("Work-Space")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/app-root/app-test-site/section[2]/div/div/div/div[1]/app-menu/div/footer/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("fullName")).sendKeys("Sarvmani Anand");
		Thread.sleep(2000);
		driver.findElement(By.id("join")).sendKeys("Kaise Ho");
		Thread.sleep(2000);
		String myValue =  driver.findElement(By.id("getMe")).getAttribute("value");
		System.out.println(myValue);
		Thread.sleep(2000);
		driver.findElement(By.id("clearMe")).clear();
		Thread.sleep(2000);
		boolean isEdit = driver.findElement(By.id("noEdit")).isEnabled();
		System.out.println(isEdit);
		String isReadOnly = driver.findElement(By.id("dontwrite")).getAttribute("readonly");
		System.out.println(isReadOnly);
		Thread.sleep(4000);
		driver.findElement(By.xpath("/html/body/app-root/app-input/section[1]")).click();
	  TakesScreenshot ss =(TakesScreenshot)driver;
	  
		File src = ss.getScreenshotAs(OutputType.FILE);
		File des= new File(".//Screenshots2//Workspace.png");
		FileUtils.copyFile(src, des);
		Thread.sleep(2000);
  }
  @Test(priority = 2 , description = "Exploring with courses Tab")
  public void courses() throws Exception 
  {
	  
	  driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[1]/a")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[1]/div/a[4]")).click();
	  Thread.sleep(2000);
	  TakesScreenshot ss =(TakesScreenshot)driver;
		File src = ss.getScreenshotAs(OutputType.FILE);
		File des= new File(".//Screenshots2//Courses.png");
		FileUtils.copyFile(src, des);
		Thread.sleep(2000);
  }
  @Test(priority = 4 , description = "Checking with Grooming Tab")
  public void grooming() throws Exception 
  {
	  driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[2]/a")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[2]/div/a[2]")).click();
	  Thread.sleep(2000);
	  TakesScreenshot ss =(TakesScreenshot)driver;
		File src = ss.getScreenshotAs(OutputType.FILE);
		File des= new File(".//Screenshots2//Grooming.png");
		FileUtils.copyFile(src, des);
		Thread.sleep(2000);
  }
  @Test(priority = 3, description = "Testing On Product Tab")
  public void product() throws Exception 
  {
	  driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/a[2]")).click();
	  Thread.sleep(2000);
	  TakesScreenshot ss =(TakesScreenshot)driver;
		File src = ss.getScreenshotAs(OutputType.FILE);
		File des= new File(".//Screenshots2//Product.png");
		FileUtils.copyFile(src, des); 
		Thread.sleep(2000);
  }
  

  @AfterTest
  public void afterTest()
  {
	  
	  driver.close();
  }

}
