package frameworks;

import org.testng.annotations.Test;

import pom.LetCode_PomClass;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class DataDrivenUsing_TestNG {
	WebDriver driver;
	
	@BeforeTest
	public void beforeTest() 
	{
		 System.setProperty("webdriver.chrome.driver",".\\Browser_Extension\\chromedriver.exe");
			 driver =new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();		
	}

	@Test(dataProvider = "dp")
	public void letCode(String email, String pwd) throws Exception
	{
		LetCode_PomClass obj=new LetCode_PomClass();
		
		obj.url(driver);
		Thread.sleep(2000);
		obj.loginButton(driver);
		Thread.sleep(2000);
		obj.enterEmail(driver, email);
		Thread.sleep(2000);
		obj.enterPassword(driver, pwd);
		Thread.sleep(2000);
		obj.clickOnLoginButton(driver);
		Thread.sleep(8000);
		obj.clickOnLogOutButton(driver);
		Thread.sleep(2000);
	}

	@DataProvider
	public Object[][] dp() 
	{
		return new Object[][] 
				{
			new Object[] { "anand234@gmail.com", "anand123" },
			new Object[] { "prmod234@gmail.com", "prm123" },
			new Object[] { "anand234@gmail.com", "anand123" },
			new Object[] { "anaad234@gmail.com", "annnad123" },
			new Object[] { "anand234@gmail.com", "anand123" },
			
				};
	}
	@AfterTest
	public void afterTest() 
	{
		driver.close();
	}

}
