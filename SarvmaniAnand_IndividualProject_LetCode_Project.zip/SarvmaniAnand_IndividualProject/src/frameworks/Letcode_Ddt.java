package frameworks;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom.LetCode_PomClass;

public class Letcode_Ddt {

	public static void main(String[] args) throws Exception {
		
		//Store Excel file path
		FileInputStream file=new FileInputStream("D:\\Automation Testing\\POI\\Frameworks_Individual.xlsx");
		//jvm will reach to excel file
		XSSFWorkbook w = new XSSFWorkbook(file);
		//Decide Unique Excel sheet
		XSSFSheet s=w.getSheet("Datadriven"); 
		//to store total no. of row
		int rowsize=s.getLastRowNum();
		System.out.println("No. of Credentials: " + rowsize);
		System.setProperty("webdriver.chrome.driver", ".\\Browser_Extension\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		
		
		for(int i=1; i<=rowsize; i++)
		{
			LetCode_PomClass obj=new LetCode_PomClass();
			//store username and password in variables
			String email=s.getRow(i).getCell(0).getStringCellValue();
			String password=s.getRow(1).getCell(1).getStringCellValue();
			System.out.println(email+"\t\t"+password);
			//Handle Exception(Invalid credentials)
			try
			{
				obj.url(driver);
				Thread.sleep(2000);
				obj.loginButton(driver);
				Thread.sleep(2000);
				obj.enterEmail(driver, email);
				Thread.sleep(2000);
				obj.enterPassword(driver, password);
				Thread.sleep(2000);
				obj.clickOnLoginButton(driver);
				Thread.sleep(8000);
				obj.clickOnLogOutButton(driver);
				Thread.sleep(2000);
				//Update test result
				System.out.println("Valid Credentials");
				s.getRow(i).createCell(2).setCellValue("Valid Credentials");
				
			}
			catch (Exception e)
			{
				System.out.println("Invalid Credentials");
				s.getRow(i).createCell(2).setCellValue("Invalid Credentials");
				
			}
		}
		// write test result on excelsheet
		FileOutputStream out = new FileOutputStream("D:\\Automation Testing\\POI\\Frameworks_Individual.xlsx");
		w.write(out);
		driver.close();
		
		
	

	}

}
