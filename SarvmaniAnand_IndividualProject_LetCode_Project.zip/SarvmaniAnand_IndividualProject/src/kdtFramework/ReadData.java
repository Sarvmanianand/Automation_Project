package kdtFramework;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;



public class ReadData {
	public void readExcelData(WebDriver driver) throws Exception {
		FileInputStream file= new FileInputStream("D:\\Automation Testing\\POI\\Frameworks_Individual.xlsx");
		XSSFWorkbook w= new XSSFWorkbook(file);
		XSSFSheet s =w.getSheet("Keyworddriven");
		int rowsize=s.getLastRowNum();
		System.out.println("No. of keywords:"+rowsize);
		OperationalClass obj=new OperationalClass();
		for(int i=1;i<=rowsize;i++) 
		{
			String key=s.getRow(i).getCell(0).getStringCellValue();

			System.out.println(key);
			if(key.equals("OpenUrl")) 
			{
				obj.url(driver);
				Thread.sleep(2000);
			}
			else if (key.equals("MaximizeBrowser"))
			{
				obj.maximizeBrowser(driver);
				Thread.sleep(2000);
			}
			else if (key.equals("LogoInButton"))
			{
				obj.loginButton(driver);
				Thread.sleep(2000);
			}

			else if(key.equals("EnterEmail")) 
			{
				obj.enterEmail(driver, "anand234@gmail.com");
				Thread.sleep(2000);

			}
			else if(key.equals("EnterPassword")) 
			{
				obj.enterPassword(driver, "anand123");
				Thread.sleep(2000);

			}
			else if(key.equals("ClickOnLoginButoon")) 
			{
				obj.clickOnLoginButton(driver);
				Thread.sleep(8000);

			}
	
			else if(key.equals("ClickOnLogOutButoon")) 
			{
				obj.clickOnLogOutButton(driver);
				Thread.sleep(2000);

			}
			else if(key.equals("CloseBrowser")) 
			{
				obj.closeBrowser(driver);

			}

		}


	}


}
