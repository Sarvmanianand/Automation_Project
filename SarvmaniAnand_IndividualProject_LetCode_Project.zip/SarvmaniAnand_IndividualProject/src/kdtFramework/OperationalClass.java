package kdtFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OperationalClass {
	public void maximizeBrowser(WebDriver driver) {
		driver.manage().window().maximize();
	}
	public void url(WebDriver driver) {
		driver.get("https://letcode.in/");
	}
	public void loginButton(WebDriver driver)
	{
		 driver.findElement(By.linkText("Log in")).click();
	}
	public void enterEmail(WebDriver driver,String email) {
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys(email);
	}
	public void enterPassword(WebDriver driver,String pwd) {
		 driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pwd);
	}
	public void clickOnLoginButton(WebDriver driver) {
		driver.findElement(By.xpath("//button[@class='button is-primary']")).click();
	}
	public void clickOnLogOutButton(WebDriver driver) {
		driver.findElement(By.linkText("Sign out")).click();
	}
	public void closeBrowser(WebDriver driver) {
		driver.close();
	 }
	

}
