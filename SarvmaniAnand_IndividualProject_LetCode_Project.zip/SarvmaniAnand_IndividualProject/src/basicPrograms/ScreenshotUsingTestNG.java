package basicPrograms;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pom.LetCode_PomClass;

public class ScreenshotUsingTestNG {
  @Test
  public void f() throws Exception {
	  LetCode_PomClass obj= new LetCode_PomClass();
	  
	  System.setProperty("webdriver.chrome.driver", ".\\Browser_Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		obj.url(driver);
		Thread.sleep(2000);
		driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        obj.loginButton(driver);
        obj.enterEmail(driver,"anand234@gmail.com");
        obj.enterPassword(driver, "anand123");
        obj.clickOnLoginButton(driver);
		
		TakesScreenshot ss =(TakesScreenshot)driver;
		File src = ss.getScreenshotAs(OutputType.FILE);
		File des= new File(".//Screenshots2//LoginSucessfully.png");
		FileUtils.copyFile(src, des);
  }
}
