package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Registration {

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver",".\\Browser_Extension\\chromedriver.exe");
         WebDriver driver=new ChromeDriver();
         driver.get("https://letcode.in/");
         Thread.sleep(2000);
         driver.manage().window().maximize();
         
         driver.manage().deleteAllCookies();
         
         driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[2]/div/div/a[1]")).click();
         
         Thread.sleep(2000);
         driver.findElement(By.id("name")).sendKeys("Anand");
         Thread.sleep(2000);
         driver.findElement(By.id("email")).sendKeys("anand234@gmail.com");
         Thread.sleep(2000);
         driver.findElement(By.id("pass")).sendKeys("anand123");
         Thread.sleep(2000);
         driver.findElement(By.xpath("//button[@class='button is-primary']")).click();
         driver.close();
         
	}

}
