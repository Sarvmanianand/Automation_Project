package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {

	public static void main(String[] args) throws Exception 
	{

		System.setProperty("webdriver.chrome.driver",".\\Browser_Extension\\chromedriver.exe");
         WebDriver driver=new ChromeDriver();
       
         driver.get("https://letcode.in/");
         Thread.sleep(2000);
         driver.manage().window().maximize();
         Thread.sleep(2000);
         driver.manage().deleteAllCookies();
         Thread.sleep(2000);
         driver.findElement(By.linkText("Log in")).click();
         Thread.sleep(2000);
         driver.findElement(By.xpath("//input[@name='email']")).sendKeys("anand234@gmail.com");
         Thread.sleep(2000);
         driver.findElement(By.xpath("//input[@name='password']")).sendKeys("anand123");
         Thread.sleep(2000);
         driver.findElement(By.xpath("//button[@class='button is-primary']")).click();
         driver.close();

	}

}