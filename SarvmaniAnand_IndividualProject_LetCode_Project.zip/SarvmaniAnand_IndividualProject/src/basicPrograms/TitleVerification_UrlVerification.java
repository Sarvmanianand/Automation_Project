package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom.LetCode_PomClass;

public class TitleVerification_UrlVerification {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\Browser_Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		LetCode_PomClass obj=new LetCode_PomClass();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		Thread.sleep(2000);
		    
			System.out.println(driver.getTitle()); 
			String acceptedTitle="LetCode with Koushik";
			String actualTitle=driver.getTitle();
			if(actualTitle.equals(acceptedTitle)) 
			{
				System.out.println("Title Verification Passed");
			}
			else
			{
				System.out.println("Title Verification failed");
			}
			//Url verification
			System.out.println(driver.getCurrentUrl());
			String acceptedUrl="https://letcode.in/";
			String actualUrl=driver.getCurrentUrl();
			if(actualUrl.equals(acceptedUrl)) 
			{
				System.out.println("Title Verification Passed");
			}
			else
			{
				System.out.println("Title Verification failed");
			}
			obj.closeBrowser(driver);
		

	}

}
