package basicPrograms;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_joption {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver",".\\Browser_Extension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		driver.get("https://letcode.in/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.manage().deleteAllCookies();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Log in")).click();

		String usn= JOptionPane.showInputDialog("Enter Username");

		driver.findElement(By.xpath("//input[@name='email']")).sendKeys(usn);

		String pswd =JOptionPane.showInputDialog("Enter Password");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pswd);		
		driver.findElement(By.xpath("//button[@class='button is-primary']")).click();
		Thread.sleep(8000);
	
		driver.findElement(By.linkText("Sign out")).click();
		driver.close();
	}

}
