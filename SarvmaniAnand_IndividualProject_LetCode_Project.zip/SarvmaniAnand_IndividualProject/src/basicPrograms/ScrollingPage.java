package basicPrograms;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom.LetCode_PomClass;

public class ScrollingPage {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver", ".\\Browser_Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		LetCode_PomClass obj=new LetCode_PomClass();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		js.executeScript("window.scrollTo(0,-document.body.scrollHeight)");
		Thread.sleep(2000);
		obj.closeBrowser(driver);

	}

}
